package main

import (
	"errors"
	"fmt"
	"time"
)

type Medicine struct {
	name            string
	manufacturer    string
	manufactureDate time.Time
	shelfLife       int
}

func NewMedicine(name, manufacturer string, manufactureDate time.Time, shelfLife int) (Medicine, error) {
	if name == "" {
		return Medicine{}, errors.New("el nombre no puede estar vacío")
	}
	if manufacturer == "" {
		return Medicine{}, errors.New("el fabricante no puede estar vacío")
	}
	if manufactureDate.IsZero() {
		return Medicine{}, errors.New("la fecha de fabricación debe ser válida")
	}
	if shelfLife <= 0 {
		return Medicine{}, errors.New("la vida útil debe ser un número positivo")
	}
	return Medicine{name: name, manufacturer: manufacturer, manufactureDate: manufactureDate, shelfLife: shelfLife}, nil
}

func (m *Medicine) GetName() string { return m.name }
func (m *Medicine) SetName(name string) error {
	if name == "" {
		return errors.New("el nombre no puede estar vacío")
	}
	m.name = name
	return nil
}

func (m *Medicine) GetManufacturer() string { return m.manufacturer }
func (m *Medicine) SetManufacturer(manufacturer string) error {
	if manufacturer == "" {
		return errors.New("el fabricante no puede estar vacío")
	}
	m.manufacturer = manufacturer
	return nil
}

func (m *Medicine) GetManufactureDate() time.Time { return m.manufactureDate }
func (m *Medicine) SetManufactureDate(date time.Time) error {
	if date.IsZero() {
		return errors.New("la fecha de fabricación debe ser válida")
	}
	m.manufactureDate = date
	return nil
}

func (m *Medicine) GetShelfLife() int { return m.shelfLife }
func (m *Medicine) SetShelfLife(months int) error {
	if months <= 0 {
		return errors.New("la vida útil debe ser un número positivo")
	}
	m.shelfLife = months
	return nil
}

func (m *Medicine) CalculateExpiryDate() time.Time {
	return m.manufactureDate.AddDate(0, m.shelfLife, 0)
}

type Tablet struct {
	Medicine
	dosePerTablet  float64
	isPrescription bool
}

func NewTablet(name, manufacturer string, manufactureDate time.Time, shelfLife int, dose float64, prescription bool) (Tablet, error) {
	base, err := NewMedicine(name, manufacturer, manufactureDate, shelfLife)
	if err != nil {
		return Tablet{}, err
	}
	if dose <= 0 {
		return Tablet{}, errors.New("la dosis por tableta debe ser mayor a 0")
	}
	return Tablet{Medicine: base, dosePerTablet: dose, isPrescription: prescription}, nil
}

func (t *Tablet) GetDosePerTablet() float64 { return t.dosePerTablet }
func (t *Tablet) SetDosePerTablet(dose float64) error {
	if dose <= 0 {
		return errors.New("la dosis debe ser mayor a 0")
	}
	t.dosePerTablet = dose
	return nil
}

func (t *Tablet) GetIsPrescription() bool  { return t.isPrescription }
func (t *Tablet) SetIsPrescription(p bool) { t.isPrescription = p }

func (t *Tablet) DisplayDetails() {
	fmt.Printf("Tablet - Nombre: %s, Fabricante: %s, Fabricación: %s, Vida Útil: %d meses, Dosis: %.2f mg, Receta: %t\n",
		t.GetName(), t.GetManufacturer(), t.GetManufactureDate().Format("2006-01-02"), t.GetShelfLife(), t.dosePerTablet, t.isPrescription)
}

type Syrup struct {
	Medicine
	volume float64
	flavor string
}

func NewSyrup(name, manufacturer string, manufactureDate time.Time, shelfLife int, volume float64, flavor string) (Syrup, error) {
	base, err := NewMedicine(name, manufacturer, manufactureDate, shelfLife)
	if err != nil {
		return Syrup{}, err
	}
	if volume <= 0 {
		return Syrup{}, errors.New("el volumen debe ser mayor a 0")
	}
	return Syrup{Medicine: base, volume: volume, flavor: flavor}, nil
}

func (s *Syrup) GetVolume() float64 { return s.volume }
func (s *Syrup) SetVolume(volume float64) error {
	if volume <= 0 {
		return errors.New("el volumen debe ser mayor a 0")
	}
	s.volume = volume
	return nil
}

func (s *Syrup) GetFlavor() string       { return s.flavor }
func (s *Syrup) SetFlavor(flavor string) { s.flavor = flavor }

func (s *Syrup) DisplayDetails() {
	fmt.Printf("Syrup - Nombre: %s, Fabricante: %s, Fabricación: %s, Vida Útil: %d meses, Volumen: %.2f ml, Sabor: %s\n",
		s.GetName(), s.GetManufacturer(), s.GetManufactureDate().Format("2006-01-02"), s.GetShelfLife(), s.volume, s.flavor)
}

func main() {
	f1 := time.Date(2025, 1, 10, 0, 0, 0, 0, time.UTC)
	f2 := time.Date(2025, 6, 15, 0, 0, 0, 0, time.UTC)

	tabletInventory := []Tablet{}
	t1, _ := NewTablet("Paracetamol", "Cruz Azul", f1, 24, 500, false)
	t2, _ := NewTablet("Amoxicilina", "Farmacia Económica", f2, 12, 875, true)
	tabletInventory = append(tabletInventory, t1, t2)

	syrupInventory := []Syrup{}
	s1, _ := NewSyrup("Ibuprofeno", "Sana Sana", f1, 18, 120, "Fresa")
	s2, _ := NewSyrup("Jarabe Tos", "Super Salud", f2, 36, 200, "Miel")
	syrupInventory = append(syrupInventory, s1, s2)

	for _, t := range tabletInventory {
		t.DisplayDetails()
	}
	for _, s := range syrupInventory {
		s.DisplayDetails()
	}

	_ = tabletInventory[0].SetName("Paracetamol Forte")
	fmt.Printf("\nMedicamento modificado: %s\n\n", tabletInventory[0].GetName())

	for _, t := range tabletInventory {
		fmt.Printf("Medicamento: %s | Caducidad: %s\n", t.GetName(), t.CalculateExpiryDate().Format("2006-01-02"))
	}
	for _, s := range syrupInventory {
		fmt.Printf("Medicamento: %s | Caducidad: %s\n", s.GetName(), s.CalculateExpiryDate().Format("2006-01-02"))
	}
}
